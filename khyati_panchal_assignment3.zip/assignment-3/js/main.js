
/********************************************************************************** 
*   WEB422 – Assignment 3 
*   I declare that this assignment is my own work in accordance with Seneca  Academic Policy.   
*   No part of this assignment has been copied manually or electronically from any other source 
*  (including web sites) or distributed to other students. 
*  
*	Name: _Khyati Panchal______ Student ID: _132297169____ Date: _October 4th, 2017_____ 
* 
* 
********************************************************************************/  

//viewModel
var viewModel = {
    teams:ko.observableArray([]),
    employees:ko.observableArray([]),
    projects:ko.observableArray([])    
};

//generic modal
function showGenericModal(title, message)
{
    $("#genericModal").modal ({
        backdrop: 'static', 
        keyboard: false, 
    });
    $("#myModalTitle").empty();
    $("#myModalMessage").empty();
    $("#myModalTitle").text(title);
    $("#myModalMessage").html(message);
}


function initializeTeams()
{
    return new Promise( function(resolve, reject) {        
        $.ajax({
            url: "https://fathomless-spire-25926.herokuapp.com/" + "teams-raw",
            method: "GET",
            contentType: "application/json"
        })
        .done(function(data) {          
            viewModel.teams = ko.mapping.fromJS(data);          
            resolve();
        })
        .fail(function(err){            
            reject("Error loading the team data.");
        });
    });
}


function initializeEmployees()
{
    return new Promise( function(resolve, reject) {
        $.ajax({
            url: "https://fathomless-spire-25926.herokuapp.com/" + "employees",
            method: "GET",
            contentType: "application/json"
        })
        .done(function(data) {   
            viewModel.employees = ko.mapping.fromJS(data);          
            resolve();
        })
        .fail(function(err){            
            reject("Error loading the team data.");
        });
    });
}


function initializeProjects()
{
    return new Promise( function(resolve, reject) {
        $.ajax({
            url: "https://fathomless-spire-25926.herokuapp.com/" + "projects",
            method: "GET",
            contentType: "application/json"
        })
        .done(function(data) {
            viewModel.projects = ko.mapping.fromJS(data);
            resolve();
        })
        .fail(function(err){              
            reject("Error loading the team data.");
        });
    });
}


function saveTeam()
{
    let current_team = this;   
    $.ajax({
        url: "https://fathomless-spire-25926.herokuapp.com/" + "team/" + current_team._id(),
        type: "PUT",
        data: JSON.stringify ( 
            {
                "Projects": current_team.Projects(), 
                "Employees": current_team.Employees(), 
                "TeamLead": current_team.TeamLead() 
            }
        ),
        contentType: "application/json"
    })
    .done(function (data) {
        showGenericModal("Success", "[" + current_team.TeamName() + "] Updated Successfully");
    })
    .fail(function (err) {
        showGenericModal("Error", "Error updating the team information.");
    });
}

$(document).ready(function(){    
    initializeTeams()
    .then(initializeEmployees)
    .then(initializeProjects)
    .then(function() { 
        ko.applyBindings(viewModel);
        $("select.multiple").multipleSelect({ filter: true });
        $("select.single").multipleSelect({ single: true, filter: true });
    })
    .catch(function(err) {
        console.log("error: " + err);
        showGenericModal('Error', err);
    });
});