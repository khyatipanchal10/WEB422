/***************************************************************************************************  
 * WEB422 – Assignment 2 *  
 * I declare that this assignment is my own work in accordance with Seneca  Academic Policy.     
 * No part of this assignment has been copied manually or electronically from any other source 
 * (including web sites) or distributed to other students. 
 *  
 * Name: KHYATI PANCHAL          Student ID: 132297169       Date: 25th September,2017
 *  
 * * ************************************************************************************************/
$(document).ready(function () {
    let employeesModel;

    //initializeEmployee Model Function
    function initializeEmployeesModel() {
        console.log("jquery working!!!");
        return new Promise(function (request, response) {
            $.ajax({
                url: "https://fathomless-spire-25926.herokuapp.com/employees",
                type: "GET",
                contentType: "application/json"
            }).done(function (data) {
                employeesModel = data;
                refreshEmployeeRows(employeesModel);
            }).fail(function (err) {
                showGenericModal('Error: Unable to connect to get Employee');
                console.log('err' + err.statusText);
            });
        });
    }

    //generic Model Function
    function showGenericModal(title, message) {
        $("#modal-title h4").text(title);
        $("#modal-body p").text(message);
        $("#genericModal").modal();
    }

    let rowtemplate = _.template(
        '<% _.forEach(employees, function(employee) { %>' +
        '<div class="row body-row" data-id=<%- employee._id %>>' +
        '<div class="col-xs-4 body-column"><%- employee.FirstName %></div>' +
        '<div class="col-xs-4 body-column"><%- employee.LastName %></div>' +
        '<div class="col-xs-4 body-column"><%- employee.Position.PositionName %></div>' +
        '</div>' +
        '<% }); %>');

    //Refresh EmployeeRows function
    function refreshEmployeeRows(employees) {
        var rowtemp = rowtemplate({ 'employees': employees });
        let body = $("#employees-table");
        //body.empty();
        body.html(rowtemp);
    }

    //getFilterEmployees Model function
    function getFilterEmployeesModel(filterString) {
        let filterData = _.filter(employeesModel, function (employee) {
            if ((employee.FirstName.toUpperCase()).indexOf(filterString.toUpperCase()) != -1 ||
                (employee.LastName.toUpperCase()).indexOf(filterString.toUpperCase()) != -1
                || (employee.Position.PositionName.toUpperCase()).indexOf(filterString.toUpperCase()) != -1) {
                return true;
            }
            else {
                return false;
            }
        });
        return filterData;
    }


    //getEmployeeModelById function
    function getEmployeeModelById(id) {
        let findIdx = _.findIndex(employeesModel, function (employee) {
            return employee._id === id;
        });
        if (findIdx != -1) {
            return _.cloneDeep(employeesModel[findIdx]);
        }
        else null;
    }

    initializeEmployeesModel();

    $("#employee-search").on("keyup", function () {
        let search = $("#employee-search").val();
        refreshEmployeeRows(getFilterEmployeesModel(search));
    });

    $(".bootstrap-header-table").on("click", ".body-row", function () {
        console.log("$(.bootstrap-header-table).on(click, .body-row, function() {");
        let $emp_id = $(this).attr("data-id");
        let empClicked = getEmployeeModelById($emp_id);

        let tempHireDate = moment(empClicked.HireDate).format("LL");
        empClicked.HireDate = tempHireDate;

        let modalTemplate = _.template(
            '<strong>Address:</strong> <%- employee.AddressStreet %> <%- employee.AddressCity %> <%- employee.AddressState %> <%- employee.AddressZip %><br>' +
            '<strong>Phone Number:</strong> <%-employee.PhoneNum %><br>' +
            '<strong>Hire Date:</strong> <%- employee.HireDate %>');

        $("#genericModal").modal({
            backdrop: 'static', // disable clicking on the backdrop to close
            keyboard: false, // disable using the keyboard to close
        });
        $("#myModalTitle").empty();
        $("#myModalMessage").empty();
        console.log(empClicked.FirstName + " " + empClicked.LastName);
        $("#myModalTitle").text(
            empClicked.FirstName + " " + empClicked.LastName);

        console.log(modalTemplate({ 'employee': empClicked }));
        $("#myModalMessage").html(modalTemplate({ 'employee': empClicked }));
    });
})

