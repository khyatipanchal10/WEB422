/***************************************************************************************************  
 * WEB422 – Assignment 1 *  
 * I declare that this assignment is my own work in accordance with Seneca  Academic Policy.     
 * No part of this assignment has been copied manually or electronically from any other source 
 * (including web sites) or distributed to other students. 
 *  
 * Name: KHYATI PANCHAL          Student ID: 132297169       Date: 14th September,2017
 *  
 * * ************************************************************************************************/  
 

$(function(){
    console.log("jQuery is working.!!");
    let tmenu = $("#team-menu");
    let emenu = $("#employees-menu");
    let projmenu = $("#projects-menu");
    let posmenu = $("#positions-menu");
    let datacont = $("#data");

    //calling the teams data
    tmenu.on("click",function(event){
        event.preventDefault();
        $.ajax({
                url : "https://fathomless-spire-25926.herokuapp.com/teams",
                type : "GET",
                contentType : "application/json"
            }).done(function(teams){
                datacont.empty();
                let header = $('<h3>').text("Teams");
                datacont.append(header);
                datacont.append(JSON.stringify(teams));
            }).fail(function(err){
                console.log("error" + err.statusText);
            });
        });

        //calling the employees data
        emenu.on("click",function(event){
            event.preventDefault();
            $.ajax({
                    url : "https://fathomless-spire-25926.herokuapp.com/employees",
                    type : "GET",
                    contentType : "application/json"
                }).done(function(employees){
                    datacont.empty();
                    let header = $('<h3>').text("Employees");
                    datacont.append(header);
                    datacont.append(JSON.stringify(employees));
                }).fail(function(err){
                    console.log("error" + err.statusText);
                });
            });
            
            //calling the project data
            projmenu.on("click",function(event){
                event.preventDefault();
                $.ajax({
                        url : "https://fathomless-spire-25926.herokuapp.com/projects",
                        type : "GET",
                        contentType : "application/json"
                    }).done(function(projects){
                        datacont.empty();
                        let header = $('<h3>').text("Projects");
                        datacont.append(header);
                        datacont.append(JSON.stringify(projects));
                    }).fail(function(err){
                        console.log("error" + err.statusText);
                    });
                });
                
                //calling the position data
                posmenu.on("click",function(event){
                    event.preventDefault();
                    $.ajax({
                            url : "https://fathomless-spire-25926.herokuapp.com/positions",
                            type : "GET",
                            contentType : "application/json"
                        }).done(function(positions){
                            datacont.empty();
                            let header = $('<h3>').text("Positions");
                            datacont.append(header);
                            datacont.append(JSON.stringify(positions));
                        }).fail(function(err){
                            console.log("error" + err.statusText);
                        });
                    });
})
