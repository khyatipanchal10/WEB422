
import React, { Component } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';

class TeamsPanel extends Component {
    constructor() {
        super();
        this.state = { teams: [] };
    }

    componentDidMount() {
        axios.get("https://lit-sierra-58746.herokuapp.com/teams-raw").then((res) => {
            this.setState({
                teams: res.data
            });
        })
    }

    render() {
        return (
                <div className="panel panel-default">
                    <div className="panel-heading">
                        <h3 className="panel-title">Teams</h3>
                    </div>
                        <div className="panel-body">
                            <div className="table-responsive overview-table">
                                <table className="table table-striped table-bordered">
                                    <tbody>
                                        {this.state.teams.map(function (team, index) {
                                            return (
                                                <tr>
                                                    <td>{team.TeamName}</td>
                                                    <td>{team.Employees.length}</td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                            <Link to="/teams" className="btn btn-primary form-control">View All Team Data</Link>
                        </div>
            </div>
        );
    }
}

export default TeamsPanel;