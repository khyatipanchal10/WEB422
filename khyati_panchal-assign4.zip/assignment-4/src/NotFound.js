import React, {Component} from 'react';
import MainContainer from './MainContainer';

class NotFound extends Component {
    render() {
        return (
            <MainContainer sidebar = ''>
                <h1 className="page-header">Projects</h1>
                <span>Page Not Found</span>
            </MainContainer>
        );
    }
}

export default NotFound;